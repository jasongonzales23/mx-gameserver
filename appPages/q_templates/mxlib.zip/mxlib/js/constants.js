var MX = MX || {};

MX.constants = {
    numberOfQuestions: 3,
    host: "127.168.1.120:8000"
}

